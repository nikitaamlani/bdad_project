import org.apache.spark.ml.feature.Imputer
import org.apache.spark.sql.types._
import org.apache.commons.io
import org.apache.spark.ml.Pipeline
import org.apache.spark.ml.classification.DecisionTreeClassificationModel
import org.apache.spark.ml.classification.DecisionTreeClassifier
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator
import org.apache.spark.ml.feature.{IndexToString, StringIndexer, VectorIndexer}
import org.apache.spark.ml.tuning.{ParamGridBuilder, TrainValidationSplit, CrossValidator}  
import org.apache.spark.ml.feature.{VectorAssembler, StringIndexer, OneHotEncoderEstimator}  
import org.apache.spark.ml.feature.{IndexToString, StringIndexer, VectorIndexer}
import org.apache.spark.ml.classification.{RandomForestClassificationModel, RandomForestClassifier}
import org.apache.spark.ml.evaluation.BinaryClassificationEvaluator
import org.apache.spark.ml.feature.{StringIndexer, VectorAssembler}
import org.apache.spark.ml.tuning.{CrossValidator, CrossValidatorModel, ParamGridBuilder}
import org.apache.spark.sql.SparkSession
import org.apache.spark.mllib.evaluation.MulticlassMetrics 
import org.apache.spark.mllib.tree.DecisionTree
import org.apache.spark.mllib.linalg.Vectors
import org.apache.spark.mllib.feature.PCA
import org.apache.spark.SparkContext 
import org.apache.spark.SparkContext._

import org.apache.spark.mllib.regression.LabeledPoint

import org.apache.spark.mllib.tree.model.DecisionTreeModel 

import org.apache.spark.mllib.regression.LabeledPoint
import org.apache.spark.mllib.tree.model.DecisionTreeModel 
import org.apache.spark.rdd.RDD

import org.apache.spark.mllib.util.MLUtils
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf
object analysis{  
    def main(args:Array[String]){
println("Starting Spark Context...")
val sc = new SparkContext()

val spark = SparkSession.builder().getOrCreate()
val creditDf = spark.read.option("header","true").option("inferSchema","true").format("csv").load("/user/nga261/a_walk_in_scala/datagenerated.csv")
	
// val cols = Array("ft1", "ft2", "ft3", "ft4", "ft5", "ft6")
					

val cols = Array("sound","number","lat","l","long","weight","wing","color","temp_min","temp_max","beak","vol","density","a")

val assembler = new VectorAssembler().setHandleInvalid("skip").setInputCols(cols).setOutputCol("features")
val featureDf = assembler.transform(creditDf)


// StringIndexer define new 'label' column with 'result' column
// val indexer = new StringIndexer().setInputCol("creditability").setOutputCol("label")
val indexer = new StringIndexer().setInputCol("variety").setOutputCol("label")

val labelDf = indexer.fit(featureDf).transform(featureDf)


val seed = 5043
val Array(trainingData, testData) = labelDf.randomSplit(Array(0.7, 0.3), seed)

// train Random Forest model with training data set
val decisionTreeClassifier= new DecisionTreeClassifier()
val decisionTreeClassifierModel = decisionTreeClassifier.fit(trainingData)

// run model with test data set to get predictions
// this will add new columns rawPrediction, probability and prediction
val predictionDf = decisionTreeClassifierModel .transform(testData)
predictionDf.show(10)
// measure the accuracy

val evaluator = new MulticlassClassificationEvaluator().setLabelCol("label").setPredictionCol("prediction").setMetricName("accuracy")
val accuracy = evaluator.evaluate(predictionDf)
println(s"Test Error = ${(1.0 - accuracy)}")
val evaluator_1 = new BinaryClassificationEvaluator().setLabelCol("label").setMetricName("areaUnderPR").setRawPredictionCol("rawPrediction")

val area_pr= evaluator_1.evaluate(predictionDf)
println("The area under PR for collected model is")
println(area_pr)




val df = spark.read.option("header","true").option("inferSchema","true").format("csv").load("/user/nga261/a_walk_in_scala/datagenerated.csv")



// Drop time column
val df1 = df.drop("time")

// Convert 'variety' data type to Double
val toDouble = udf[Double, Int]( _.toDouble)
val df2 = df1.withColumn("variety", toDouble(df("variety")))

// Replace Nan value with mean of the columns
val imputer = new Imputer().setInputCols(df2.columns).setOutputCols(df2.columns.map(c => s"${c}")).setStrategy("mean")

val dfClean = imputer.fit(df2).transform(df2)
dfClean.show(20)
val path="/user/nga261/a_walk_in_scala/cleaned/"

//dfClean.coalesce(1).write.csv("/user/nga261/a_walk_in_scala/cleaned/")
val rdd = sc.textFile("/user/nga261/a_walk_in_scala/cleaned/").map(line => line.split(","))

val data = rdd.map(row => 
    new LabeledPoint(
          row(0).toDouble, 
          Vectors.dense(row.takeRight(row.length - 1).map(str => str.toDouble))
    )
  ).cache()

// Compute the top 5 principal components.
val pca = new PCA(8).fit(data.map(_.features))
val projected = data.map(p => p.copy(features = pca.transform(p.features)))
projected.take(10).foreach(println)

val path_1="/user/nga261/a_walk_in_scala/pca_op_1"

//MLUtils.saveAsLibSVMFile(projected.coalesce(1), "/user/nga261/a_walk_in_scala/pca_op_1")
// Load the data stored in LIBSVM format as a DataFrame.


val data_1 = spark.read.format("libsvm").load("/user/nga261/a_walk_in_scala/pca_op_1")


val labelIndexer = new StringIndexer().setInputCol("label").setOutputCol("indexedLabel").fit(data_1)
// Automatically identify categorical features, and index them.
val featureIndexer = new VectorIndexer().setInputCol("features").setOutputCol("indexedFeatures").setMaxCategories(4).fit(data_1)

// Split the data into training and test sets (30% held out for testing).
val Array(trainingData_1, testData_1) = data_1.randomSplit(Array(0.7, 0.3),seed)

// Train a DecisionTree model.
val dt = new DecisionTreeClassifier().setLabelCol("indexedLabel").setFeaturesCol("indexedFeatures")
dt.setMaxDepth(10)
// Convert indexed labels back to original labels.
val labelConverter = new IndexToString().setInputCol("prediction").setOutputCol("predictedLabel").setLabels(labelIndexer.labels)

// Chain indexers and tree in a Pipeline.
val pipeline = new Pipeline().setStages(Array(labelIndexer, featureIndexer, dt, labelConverter))

// Train model. This also runs the indexers.
val model = pipeline.fit(trainingData_1)

// Make predictions.
val predictions = model.transform(testData_1)

// Select example rows to display.
predictions.select("predictedLabel", "label", "features").show(5)

// Select (prediction, true label) and compute test error.
val evaluator_5 = new MulticlassClassificationEvaluator().setLabelCol("indexedLabel").setPredictionCol("prediction").setMetricName("accuracy")
val accuracy_1 = evaluator_5.evaluate(predictions)
println(s"Test Error = ${(1.0 - accuracy_1)}")

val evaluator_2 = new BinaryClassificationEvaluator().setLabelCol("label").setMetricName("areaUnderPR").setRawPredictionCol("rawPrediction")

val area_pr_1= evaluator_2.evaluate(predictions)
println("The area under PR for collected model is")
println(area_pr_1)



println("Fixing the class imbalance")
val df_6 = spark.read.option("header","true").option("inferSchema","true").format("csv").load("/user/nga261/a_walk_in_scala/datagenerated.csv")



val fraudDf = df_6.filter("variety=1.0")
val nonFraudDf = df_6.filter("variety=0.0")
val sampleRatio = fraudDf.count().toDouble / df.count().toDouble
val nonFraudSampleDf = nonFraudDf.sample(false, sampleRatio)
fraudDf.unionAll(nonFraudSampleDf)
val cols_1 = Array("sound","number","lat","l","long","weight","wing","color","temp_min","temp_max","beak","vol","density","a")

val assembler_1 = new VectorAssembler().setHandleInvalid("skip").setInputCols(cols_1).setOutputCol("features")
val featureDf_1 = assembler_1.transform(fraudDf)


// StringIndexer define new 'label' column with 'result' column
// val indexer = new StringIndexer().setInputCol("creditability").setOutputCol("label")
val indexer_1 = new StringIndexer().setInputCol("variety").setOutputCol("label")

val labelDf_1 = indexer_1.fit(featureDf_1).transform(featureDf_1)



val Array(trainingData_4, testData_4) = labelDf_1.randomSplit(Array(0.7, 0.3), seed)

// train Random Forest model with training data set
val decisionTreeClassifier_1= new DecisionTreeClassifier()
val decisionTreeClassifierModel_1 = decisionTreeClassifier_1.fit(trainingData_4)

// run model with test data set to get predictions
// this will add new columns rawPrediction, probability and prediction
val predictionDf_1 = decisionTreeClassifierModel_1.transform(testData_4)
predictionDf_1.show(10)
// measure the accuracy

val evaluator_4 = new MulticlassClassificationEvaluator().setLabelCol("label").setPredictionCol("prediction").setMetricName("accuracy")
val accuracy_4 = evaluator_4.evaluate(predictionDf_1)
printf(s"Test Error = ${(1.0 - accuracy_4)}")

sc.stop()
}
}

